<?php
session_start();

if (isset($_GET['frete'])) {
    $frete = $_GET['frete'];

}
?>